package com.example.weighttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.weighttracker.ui.login.LoginActivity;
import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {
    TextView signin, forgotpass;
    EditText username, password;
    Button signup;
    MaterialButton login;
    DBHelper DB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize EditText Variables
        username=(EditText) findViewById(R.id.username);
        password=(EditText) findViewById(R.id.password);

        //Initialize TextView variables
        forgotpass=(TextView) findViewById(R.id.forgotpass);
        signin=(TextView) findViewById(R.id.signin);

        //Initialize button variable
        signup=(Button) findViewById(R.id.signupbtn);
        login=(MaterialButton)findViewById(R.id.loginbtn);

        DB = new DBHelper(this);

        //Create listeners for buttons
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String pass= password.getText().toString();

                if ((user.equals("")||pass.equals("")))
                    Toast.makeText(MainActivity.this,"Fill In All Fields",Toast.LENGTH_SHORT).show();
                else{
                    if (pass.equals(pass)){
                        Boolean checkusername = DB.checkusername(user);
                        if (checkusername==false){
                            Boolean insert = DB.insertData(user,pass);
                            if (insert==true){
                                Toast.makeText(MainActivity.this,"Sign up Successful",Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(),HomeActivity.class);
                                startActivity(intent);
                            }
                            else {
                                Toast.makeText(MainActivity.this,"Sign up Failed",Toast.LENGTH_SHORT).show();
                            }
                        }
                        else {
                            Toast.makeText(MainActivity.this,"User Already Exist. Please Sign in!",Toast.LENGTH_SHORT).show();
                        }
                    }
                    else {
                        Toast.makeText(MainActivity.this,"Password Incorrect",Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });
        signin.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new  Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }
        }));
    }
}