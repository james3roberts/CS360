package com.example.weighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {
    EditText goalweight, currentweight;
    Button weightleft;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        //initialize variables
        goalweight = (EditText) findViewById(R.id.goalweight);
        //int newGWeight;
        currentweight = (EditText) findViewById(R.id.currentweight);
        //int newCWeight;
        weightleft = (Button) findViewById(R.id.weightleft);
        //int newWLeft;

        //create listeners for buttons
        goalweight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String gWeight = goalweight.getText().toString();
                if (gWeight.equals(""))
                    Toast.makeText(HomeActivity.this, "Must add Goal Weight", Toast.LENGTH_SHORT).show();
            }
        });
        currentweight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cWeight = currentweight.getText().toString();
                if (cWeight.equals(""))
                    Toast.makeText(HomeActivity.this, "Must add Current Weight", Toast.LENGTH_SHORT).show();
            }
        });
        weightleft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double a,b,c;
                a = Double.parseDouble(currentweight.getText().toString());
                b = Double.parseDouble(goalweight.getText().toString());
                c=a-b;

            }
        });
    }
}


